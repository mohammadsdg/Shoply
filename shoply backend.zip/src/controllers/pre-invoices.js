import PreInvoiceService from "../services/pre-invoices.js";
export default class PreInvoiceController {
    // Create a private PreInvoiceService instance
    preInVoiceService;
    constructor(preInVoiceService) {
        this.preInVoiceService = preInVoiceService;
    }
    // Get all the items of a stock that are pending to be approved
    getAllPreInvoices = async (req, res) => {
        const { status, shop_id } = req.query;
        const shopId = Number(shop_id);
        if (status !== 'pending' && status !== 'approved' || !shopId) {
            return res.status(400).json({
                success: false,
                body: null,
                message: "Invalid request"
            });
        }
        const conditions = {
            status: status,
            shopId
        };
        try {
            const pendingItems = await this.preInVoiceService.getAllPreInvoices(conditions);
            return res.status(200).json({
                success: true,
                body: pendingItems,
                message: `All ${status} items received successfully`
            });
        }
        catch (err) {
            if (err instanceof Error) {
                return res.status(500).json({
                    status: false,
                    body: null,
                    message: err.message
                });
            }
            return res.status(500).json({
                status: false,
                body: null,
                message: "Unknown message"
            });
        }
    };
    // Create pending item
    setPreInvoice = async (req, res) => {
        // Destructuring datas from Request.body
        const { customer_name, number, price, width, stock_item_id, weight } = req.body;
        // Check if request is valid
        if (!customer_name ||
            !number ||
            !width ||
            !price ||
            !stock_item_id ||
            !weight) {
            return res.status(400).json({
                success: false,
                body: null,
                message: "Invalid request"
            });
        }
        const preInvoicePendingInput = {
            customer_name,
            number,
            price,
            width,
            stock_item_id,
            weight
        };
        // Sending request to mysql and return a response
        try {
            const pendingItems = await this.preInVoiceService.setPending(preInvoicePendingInput);
            return res.status(201).json({
                success: false,
                body: pendingItems,
                message: 'item is successfully pending to be approved'
            });
        }
        catch (err) {
            console.log(err);
            // handle Mysql-specifig errors safely
            if (typeof err === 'object' && err !== null) {
                const anyErr = err;
                if (anyErr.code === 'ER_NO_REFERENCED_ROW_2' && anyErr.errno === 1452) {
                    return res.status(400).json({
                        status: false,
                        body: null,
                        message: 'Foreign key constraint failed',
                    });
                }
            }
            if (err instanceof Error) {
                return res.status(500).json({
                    status: false,
                    body: null,
                    message: err.message
                });
            }
            return res.status(500).json({
                status: false,
                body: null,
                message: "Unknown message"
            });
        }
    };
    // Update multiple pre_invoice.status from pending to approved
    updatePreInvoice = async (req, res) => {
        // Destructure datas from Request.body
        const { pending_items: pendingItems, sold_items: soldItems } = req.body;
        if (!Array.isArray(pendingItems) || !Array.isArray(soldItems)) {
            return res.status(400).json({
                success: false,
                body: null,
                message: "Invalid request"
            });
        }
        // Check if required sold inputs exists and are not null
        const invalidSoldItem = soldItems.find(item => {
            const checkExists = [
                item.sold_width,
                item.width,
                item.product_size_id,
                item.ID
            ].some(value => value === undefined || value === null);
            if (checkExists) {
                return true;
            }
            // if parent_id and single_product_code are undefined return true
            return item.single_product_code === undefined ? true :
                item.parent_id === undefined ? true : false;
        });
        // Check if required approved inputs exists and are not null
        const invalidMarkedItem = pendingItems.find(item => {
            const checkExists = [
                item.ID,
                item.customer_name,
                item.number,
                item.price,
                item.status,
                item.stock_item_id,
                item.weight,
            ].some(value => value === undefined || value === null);
            if (checkExists) {
                return true;
            }
        });
        // Check if request is valid
        if (invalidMarkedItem || invalidSoldItem) {
            return res.status(400).json({
                success: false,
                body: null,
                message: "Invalid request"
            });
        }
        const correctSoldItems = soldItems.filter(item => {
            return {
                width: item.width,
                product_size_id: item.product_size_id,
                ID: item.ID
            };
        });
        // Sending a request to approve pendingItems and create new items
        try {
            const result = await this.preInVoiceService.setApproved(pendingItems, correctSoldItems);
            return res.status(200).json({
                success: true,
                body: result,
                message: "pre-invoice updated successfully"
            });
        }
        catch (err) {
            console.log(err);
            // handle Mysql-specifig errors safely
            if (typeof err === 'object' && err !== null) {
                const anyErr = err;
                if (anyErr.code === 'ER_NO_REFERENCED_ROW_2' && anyErr.errno === 1452) {
                    return res.status(400).json({
                        status: false,
                        body: null,
                        message: 'Foreign key constraint failed',
                    });
                }
            }
            if (err instanceof Error) {
                return res.status(500).json({
                    status: false,
                    body: null,
                    message: err.message
                });
            }
            return res.status(500).json({
                status: false,
                body: null,
                message: "Unknown message"
            });
        }
    };
}
//# sourceMappingURL=pre-invoices.js.map