import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Layout from "../components/Layout/Layout";
import {
  Box,
  Typography,
  Card,
  CardContent,
  IconButton,
  Button,
  Modal,
  TextField,
  Skeleton,
} from "@mui/material";
import { Circle, CheckCircle } from "lucide-react";
import toast, { Toaster } from "react-hot-toast";
import api from "../api";
import _ from "lodash";

function ShopDetails() {
  const { shopId } = useParams();
  const [allProducts, setAllProducts] = useState([]);
  const [shopProducts, setShopProducts] = useState([]);
  const [shopName, setShopName] = useState("");
  const [role, setRole] = useState("");
  const [loading, setLoading] = useState(true);

  // modal state
  const [open, setOpen] = useState(false);
  const [selectedShopProductId, setSelectedShopProductId] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [formData, setFormData] = useState({
    param_one: "",
    param_two: "",
    param_three: "",
    width: "",
    number: "",
    weight: "",
    price: "",
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const storedRole = localStorage.getItem("role");
        setRole(storedRole);

        await Promise.all([
          fetchShopName(),
          fetchShopProducts(),
          fetchAllProducts(),
        ]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [shopId]);

  const fetchAllProducts = async () => {
    try {
      const res = await api.get("/products");
      setAllProducts(res.data.body || []);
    } catch (err) {
      console.error(err);
      toast.error("خطا در دریافت همه محصولات");
    }
  };

  const fieldLabels = {
    width: "طول",
    number: "تعداد",
    weight: "وزن",
    price: "قیمت",
  };

  const fetchShopName = async () => {
    try {
      const res = await api.get("/shops");
      const shops = res.data.body || [];
      const shop = shops.find((s) => s.ID === Number(shopId));
      setShopName(shop ? shop.name : "");
    } catch (err) {
      console.error(err);
      toast.error("خطا در دریافت اطلاعات فروشگاه");
      setShopName("");
    }
  };

  const fetchShopProducts = async () => {
    try {
      const res = await api.get(`/shop-products/${shopId}`);
      setShopProducts(res.data.body || []);
    } catch (err) {
      console.error(err);
      toast.error("خطا در دریافت محصولات فروشگاه");
    }
  };

  const handleToggleProduct = async (productId, isInShop) => {
    try {
      if (isInShop) {
        const shopProduct = shopProducts.find(
          (sp) => sp.product_id === productId
        );
        if (!shopProduct) return;
        await api.delete(`/shop-products/${shopProduct.ID}`);
        toast.success("محصول از فروشگاه حذف شد");
      } else {
        await api.post("/shop-products", {
          shop_id: shopId,
          product_id: productId,
        });
        toast.success("محصول به فروشگاه اضافه شد");
      }
      fetchShopProducts();
    } catch (err) {
      console.error(err);
      toast.error("مشکلی پیش آمد");
    }
  };

  const handleAddSizing = (product) => {
    setSelectedShopProductId(product.shopProductId ?? null);
    setSelectedProduct(product);
    setFormData({
      param_one: "",
      param_two: "",
      param_three: "",
      width: "",
      number: "",
      weight: "",
      price: "",
    });
    setOpen(true);
  };

  const getFieldsBySection = (sectionName) => {
    switch (sectionName) {
      case "گرد":
        return [{ name: "param_one", label: "قطر" }];
      case "ورق":
        return [
          { name: "param_one", label: "ضخامت" },
          { name: "param_two", label: "عرض" },
        ];
      case "لوله":
        return [
          { name: "param_one", label: "قطر خارجی" },
          { name: "param_two", label: "قطر داخلی" },
        ];
      case "تسمه":
        return [
          { name: "param_one", label: "ضخامت" },
          { name: "param_two", label: "عرض" },
        ];
      case "شش پر":
        return [{ name: "param_one", label: "آچارخور" }];
      default:
        return [];
    }
  };

  const handleSaveSizing = async () => {
    try {
      const payload = {
        shop_products_id: selectedShopProductId,
        param_one: formData.param_one || null,
        param_two: formData.param_two || null,
        param_three: formData.param_three || null,
        width: formData.width || null,
        number: formData.number || null,
        weight: formData.weight || null,
        price: formData.price || null,
        section_id: selectedProduct?.section_id ?? null,
      };

      await api.post("/products-size", payload);
      toast.success("سایزبندی با موفقیت ذخیره شد");
      setOpen(false);
    } catch (err) {
      console.error(err);
      toast.error("خطا در ذخیره سایزبندی");
    }
  };

  const shopProductIds = new Set(shopProducts.map((p) => p.product_id));
  const sortedProducts = _.sortBy(allProducts, (product) =>
    shopProductIds.has(product.ID) ? 0 : 1
  );

  const shopProductsWithDetails = shopProducts.map((sp) => {
    const product = allProducts.find((p) => p.ID === sp.product_id) || {};
    return {
      ...product,
      shopProductId: sp.ID,
      shopProduct: sp,
      section_id: sp.section_id ?? product.section_id,
    };
  });

  const modalBox = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    borderRadius: "8px",
  };

  // 🔹 SKELETON placeholders (while loading)
  const renderSkeletons = (count = 5) =>
    Array.from({ length: count }).map((_, i) => (
      <Card key={i} sx={{ mb: 2 }}>
        <CardContent
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ flex: 1 }}>
            <Skeleton variant="text" width="60%" height={30} />
            <Skeleton variant="text" width="40%" height={20} />
          </Box>
          <Skeleton variant="circular" width={40} height={40} />
        </CardContent>
      </Card>
    ));

  return (
    <Layout>
      <Toaster position="top-center" />

      {loading ? (
        <>
          <Typography variant="h4" sx={{ mb: 3, fontWeight: 600 }}>
            <Skeleton width="50%" />
          </Typography>
          {renderSkeletons(6)}
        </>
      ) : shopName === "" ? (
        <h1>هیچ فروشگاهی پیدا نشد</h1>
      ) : (
        <>
          <Typography variant="h4" sx={{ mb: 3, fontWeight: 600 }}>
            مدیریت محصولات فروشگاه {shopName || shopId}
          </Typography>

          {role === "super-admin" &&
            sortedProducts.map((product) => {
              const isInShop = shopProductIds.has(product.ID);
              return (
                <Card key={product.ID} sx={{ mb: 2 }}>
                  <CardContent
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                    <Box>
                      <Typography variant="h6">{product.alloyName}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {product.sectionName} | {product.materialName} |{" "}
                        {product.brandName}
                      </Typography>
                    </Box>

                    <IconButton
                      onClick={() => handleToggleProduct(product.ID, isInShop)}
                    >
                      {isInShop ? (
                        <CheckCircle color="green" />
                      ) : (
                        <Circle color="gray" />
                      )}
                    </IconButton>
                  </CardContent>
                </Card>
              );
            })}

          {role === "shop-admin" &&
            shopProductsWithDetails.map((product) => (
              <Card key={product.shopProductId} sx={{ mb: 2 }}>
                <CardContent
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <Box>
                    <Typography variant="h6">{product.alloyName}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {product.sectionName} | {product.materialName} |{" "}
                      {product.brandName}
                    </Typography>
                  </Box>

                  <Button
                    variant="contained"
                    onClick={() => handleAddSizing(product)}
                  >
                    سایزبندی
                  </Button>
                </CardContent>
              </Card>
            ))}
        </>
      )}

      <Modal open={open} onClose={() => setOpen(false)}>
        <Box sx={modalBox}>
          <Typography variant="h5" sx={{ fontWeight: 600, mb: 2 }}>
            سایزبندی جدید
          </Typography>

          {selectedProduct &&
            getFieldsBySection(selectedProduct.sectionName).map((field) => (
              <TextField
                key={field.name}
                label={field.label}
                fullWidth
                value={formData[field.name]}
                onChange={(e) =>
                  setFormData({ ...formData, [field.name]: e.target.value })
                }
                sx={{ mb: 2 }}
              />
            ))}

          {["width", "number", "weight", "price"].map((field) => (
            <TextField
              key={field}
              label={fieldLabels[field]}
              fullWidth
              value={formData[field] ?? ""}
              onChange={(e) =>
                setFormData({ ...formData, [field]: e.target.value })
              }
              sx={{ mb: 2 }}
            />
          ))}

          <Button
            variant="contained"
            fullWidth
            onClick={handleSaveSizing}
            sx={{ mt: 1 }}
          >
            ذخیره
          </Button>
        </Box>
      </Modal>
    </Layout>
  );
}

export default ShopDetails;
