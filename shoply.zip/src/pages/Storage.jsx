import React, { useEffect, useState, useMemo } from "react";
import Layout from "../components/Layout/Layout";
import {
  Box,
  Typography,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Modal,
} from "@mui/material";
import { ArrowBigLeftDashIcon, ArrowBigRightDashIcon } from "lucide-react";
import toast, { Toaster } from "react-hot-toast";
import api from "../api";

function Storage() {
  const [storageItems, setStorageItems] = useState([]);
  const [shopName, setShopName] = useState("");
  const [shopId, setShopId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [open, setOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [soldWidth, setSoldWidth] = useState("");
  const [customerName, setCustomerName] = useState(""); // optional
  const itemsPerPage = 10;

  useEffect(() => {
    fetchUserShop();
  }, []);

  // ✅ Find user's shop
  const fetchUserShop = async () => {
    try {
      const userId = localStorage.getItem("user_id");
      if (!userId) {
        toast.error("کاربر یافت نشد. لطفاً وارد شوید.");
        return;
      }

      const res = await api.get("/shops");
      const shops = res.data.body || [];
      const userShop = shops.find((s) => s.user_id === Number(userId));

      if (userShop) {
        setShopId(userShop.ID);
        setShopName(userShop.name);
        fetchStorage(userShop.ID);
      } else {
        toast.error("هیچ فروشگاهی برای این کاربر یافت نشد.");
      }
    } catch (err) {
      console.error(err);
      toast.error("خطا در دریافت اطلاعات فروشگاه");
    }
  };

  // ✅ Fetch storage (product sizes)
  const fetchStorage = async (shopId) => {
    try {
      const res = await api.get(`/products-size?shop_id=${shopId}`);
      setStorageItems(res.data.body || []);
    } catch (err) {
      console.error(err);
      toast.error("خطا در دریافت محصولات انبار");
    }
  };

  // ✅ Handle create pre-invoice (instead of direct sell)
  const handleOrder = async () => {
    if (!selectedItem) return;
    if (!soldWidth || isNaN(Number(soldWidth)) || Number(soldWidth) <= 0) {
      toast.error("لطفاً مقدار معتبر برای عرض وارد کنید");
      return;
    }

    try {
      const payload = {
        customer_name: customerName || "مشتری پیش‌فرض",
        number: Math.floor(Math.random() * 1000), // auto temporary number
        price: selectedItem.price || 0,
        stock_item_id: selectedItem.ID,
        weight: selectedItem.weight || 0,
        width: Number(soldWidth),
      };

      await api.post("/api/v1/pre-invoices", payload);
      toast.success("سفارش با موفقیت در حالت انتظار ثبت شد ✅");

      setOpen(false);
      setSoldWidth("");
      setCustomerName("");
      setSelectedItem(null);
      fetchStorage(shopId); // refresh
    } catch (err) {
      console.error(err);
      toast.error("خطا در ثبت پیش‌فاکتور");
    }
  };

  // ✅ Filtering
  const filteredItems = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return storageItems.filter(
      (item) =>
        item.section_name?.toLowerCase().includes(term) ||
        String(item.price).includes(term) ||
        String(item.width).includes(term)
    );
  }, [storageItems, searchTerm]);

  // ✅ Pagination
  const currentItems = useMemo(() => {
    const last = currentPage * itemsPerPage;
    const first = last - itemsPerPage;
    return filteredItems.slice(first, last);
  }, [filteredItems, currentPage]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);

  // ✅ Modal style
  const modalBox = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    borderRadius: "8px",
  };

  return (
    <Layout>
      <Toaster position="top-center" />
      <Typography variant="h4" sx={{ mb: 3, fontWeight: 600 }}>
        {shopName ? `انبار فروشگاه ${shopName}` : "در حال بارگذاری انبار..."}
      </Typography>

      <Box sx={{ display: "flex", gap: 2, mb: 2, alignItems: "center" }}>
        <TextField
          placeholder="جستجوی محصول..."
          variant="outlined"
          size="small"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          sx={{ minWidth: "90%" }}
        />
      </Box>

      <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
        <Table sx={{ "& *": { fontSize: "14px !important" } }}>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>نام مقطع</TableCell>
              <TableCell>عرض</TableCell>
              <TableCell>وزن</TableCell>
              <TableCell>تعداد</TableCell>
              <TableCell>قیمت</TableCell>
              <TableCell>وضعیت</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {currentItems.length > 0 ? (
              currentItems.map((item) => (
                <TableRow key={item.ID} hover>
                  <TableCell>{item.ID}</TableCell>
                  <TableCell>{item.section_name || "-"}</TableCell>
                  <TableCell>{item.width ?? "-"}</TableCell>
                  <TableCell>{item.weight ?? "-"}</TableCell>
                  <TableCell>{item.number ?? "-"}</TableCell>
                  <TableCell>{item.price ?? "-"}</TableCell>
                  <TableCell>
                    {item.status === 10 ? "فعال" : "غیرفعال"}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  هیچ محصولی یافت نشد
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      <Box sx={{ display: "flex", justifyContent: "center", mt: 2, gap: 1 }}>
        <Button
          variant="text"
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((p) => p - 1)}
        >
          <ArrowBigRightDashIcon />
        </Button>
        <Typography>
          {currentPage} / {totalPages || 1}
        </Typography>
        <Button
          variant="text"
          disabled={currentPage === totalPages || totalPages === 0}
          onClick={() => setCurrentPage((p) => p + 1)}
        >
          <ArrowBigLeftDashIcon />
        </Button>
      </Box>
    </Layout>
  );
}

export default Storage;
